#include "StdAfx.h"
#include "Mesh.h"
#include <algorithm>
#include <sstream>
#include<math.h>
#include<omp.h>
#define NUM_THREADS 8
Mesh::Mesh(void)
{
	mesh.request_face_colors();
	mesh.request_vertex_colors();
	mesh.request_face_normals();
	mesh.request_vertex_normals();
	Vx.clear();Nx.clear();
	Vy.clear();Ny.clear();
	Vz.clear();Nz.clear();
	Edges.clear();Points.clear(); Faces.clear();
	Fnormalx.clear(); Fnormaly.clear(); Fnormalz.clear();
	maxx = -1000;maxy = -1000;maxz = -1000;
	minx = 1000; miny = 1000; minz = 1000;
	flags = 0;  meshflags = 0;
}


Mesh::~Mesh(void)
{
	Vx.clear();Nx.clear();
	Vy.clear();Ny.clear();
	Vz.clear();Nz.clear();
	Edges.clear();Points.clear(); Faces.clear();
	Fnormalx.clear(); Fnormaly.clear(); Fnormalz.clear();
}




void Mesh::readMeshFile(const string & filename)
{

	if(!OpenMesh::IO::read_mesh(mesh,filename))
	{
		std::cerr<<"read error\n";
		exit(1);
	}

}



void Mesh::almMeshSmoothing(double fidPara,double lapPara,double r,double regParam,double nIndex)
{
	cout<<"vNumbers"<<mesh.n_vertices()<<"   fNubmers"<<mesh.n_faces()<<" eNumbers  "<<mesh.n_edges()<<endl;

	cout<<fidPara<<"  "<<lapPara<<"  "<<r<<"  "<<regParam<<endl;
	omp_set_num_threads(NUM_THREADS);
	clock_t start,end;
//	cout<<"almmeshsmoothing"<<endl;
	
	vNumber = mesh.n_vertices();
	fNumber = mesh.n_faces();
	eNumber = mesh.n_edges();
	int dimension = fNumber;
	
	 vector<MyMesh::Point> rPositions(fNumber);
	 vector<MyMesh::Point> oldVertex(vNumber);
	
	computeTemp();
	computeMeshCoeff(); 
	faceneighbor();
	/*   Parameters setting  */
	
	mesh.update_normals();	
	for (MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		int fIndex = fIt.handle().idx();	
	    rPositions[fIndex][0] = mesh.normal(fIt)[0];//含噪音的法向
		rPositions[fIndex][1] = mesh.normal(fIt)[1];
		rPositions[fIndex][2] = mesh.normal(fIt)[2];
	}
	for(MyMesh::VertexIter vIt = mesh.vertices_begin(); vIt != mesh.vertices_end(); ++vIt)
	{
		int vIndex = vIt.handle().idx();
		oldVertex[vIndex][0] = mesh.point(vIt)[0];
		oldVertex[vIndex][1] = mesh.point(vIt)[1];
		oldVertex[vIndex][2] = mesh.point(vIt)[2];
	}
	     Fnormalx.resize(fNumber); Fnormaly.resize(fNumber); Fnormalz.resize(fNumber);
	     mesh.update_face_normals();
	 for(MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		int fIndex = fIt.handle().idx();		
		Fnormalx[fIndex] = mesh.normal(fIt)[0];
		Fnormaly[fIndex] = mesh.normal(fIt)[1];
		Fnormalz[fIndex] = mesh.normal(fIt)[2];
	
	}
	OurDenoisingMethod(fidPara,r,rPositions);
	UpdateVertex();
 
}
void Mesh::computeMeshCoeff(void)
{
	int vNumber=mesh.n_vertices(); int fNumber=mesh.n_faces();
	faceArea_.resize(fNumber);
	mesh.update_normals();                                                                                                                                                                                                                                                                                                                                                

	for (MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		int fIndex = fIt.handle().idx();
		vertex p0,p1,p2;
		MyMesh::FaceVertexIter fv_it = mesh.fv_iter(fIt.handle());
		int v0 = fv_it.handle().idx();     p0.x = mesh.point(fv_it).values_[0];p0.y = mesh.point(fv_it).values_[1];p0.z = mesh.point(fv_it).values_[2];
		int v1 = (++fv_it).handle().idx(); p1.x = mesh.point(fv_it).values_[0];p1.y = mesh.point(fv_it).values_[1];p1.z = mesh.point(fv_it).values_[2];
		int v2 = (++fv_it).handle().idx(); p2.x = mesh.point(fv_it).values_[0];p2.y = mesh.point(fv_it).values_[1];p2.z = mesh.point(fv_it).values_[2];
		faceArea_[fIndex] =triangleSurfaceArea(p0,p1,p2);//每个面的面积
	}

}


void Mesh::addGaussianNoise(int eigIndex,double variance)
{
	int nRow=featureDatas_.nrows();

	for(int i=0;i<nRow;i++)
	{
		featureDatas_(i,eigIndex)+=variance*GaussianRandom();
	}
}

double Mesh::GaussianRandom(void)
{
	double x1,x2,w,y1,y2;
	do
	{
		x1=2.0*double(rand())/RAND_MAX-1.0;
		x2=2.0*double(rand())/RAND_MAX-1.0;
		w=x1*x1+x2*x2;
	}while(w>=1.0);

	w=sqrt((-2.0*log(w))/w);
	y1=x1*w;  y2=x2*w;

	return y1;

}	

double Mesh::triangleSurfaceArea(const vertex & pointA, const vertex &pointB, const vertex & pointC)
{

	double a, b,c;

	a = sqrt((pointA.x-pointB.x)*(pointA.x-pointB.x)+(pointA.y-pointB.y)*(pointA.y-pointB.y)+(pointA.z-pointB.z)*(pointA.z-pointB.z));
	b = sqrt((pointC.x-pointB.x)*(pointC.x-pointB.x)+(pointC.y-pointB.y)*(pointC.y-pointB.y)+(pointC.z-pointB.z)*(pointC.z-pointB.z));
	c = sqrt((pointC.x-pointA.x)*(pointC.x-pointA.x)+(pointC.y-pointA.y)*(pointC.y-pointA.y)+(pointC.z-pointA.z)*(pointC.z-pointA.z));

	double s = .5 * (a+b+c);
	double sqrA = s*(s-a)*(s-b)*(s-c);
	if (sqrA < 0) {
		sqrA = 0;
	}
	return sqrt(sqrA);
}



void Mesh::output(void)
{ 
	int k=0;
	Vx.clear();Nx.clear();
	Vy.clear();Ny.clear();
	Vz.clear();Nz.clear();
	Vx.resize(mesh.n_vertices()); Vy.resize(mesh.n_vertices()); Vz.resize(mesh.n_vertices());
	Nx.resize(mesh.n_faces()); Ny.resize(mesh.n_faces()); Nz.resize(mesh.n_faces());
	mesh.update_normals();
	for(MyMesh::VertexIter v_it=mesh.vertices_begin();			
		v_it!=mesh.vertices_end();++v_it)
	{
		int vIndex = v_it.handle().idx();
		if(maxx<mesh.point(v_it).values_[0])maxx=mesh.point(v_it)[0];
		if(maxy<mesh.point(v_it).values_[1])maxy=mesh.point(v_it)[1];
		if(maxz<mesh.point(v_it).values_[2])maxz=mesh.point(v_it)[2];
		if(minx>mesh.point(v_it).values_[0])minx=mesh.point(v_it)[0];
		if(miny>mesh.point(v_it).values_[1])miny=mesh.point(v_it)[1];
		if(minz>mesh.point(v_it).values_[2])minz=mesh.point(v_it)[2];

		Vx[vIndex]=mesh.point(v_it)[0];
		Vy[vIndex]=mesh.point(v_it)[1];
		Vz[vIndex]=mesh.point(v_it)[2];

	}
//	cout<<"outface:"<<endl;
	face Face;
	for(MyMesh::FaceIter f_it=mesh.faces_begin();f_it!=mesh.faces_end();++f_it)
	{
		int fIndex = f_it.handle().idx();
		MyMesh::FaceVertexIter fv_it=mesh.fv_iter(f_it.handle());
		vertex a,b,c,v;
		fv_it.handle().idx();
		a.x=mesh.point(fv_it)[0];a.y=mesh.point(fv_it)[1];a.z=mesh.point(fv_it)[2];  
		(++fv_it).handle().idx();
		b.x=mesh.point(fv_it)[0];b.y=mesh.point(fv_it)[1];b.z=mesh.point(fv_it)[2];
		(++fv_it).handle().idx();
		c.x=mesh.point(fv_it)[0];c.y=mesh.point(fv_it)[1];c.z=mesh.point(fv_it)[2];
		v=faceNomal(a,b,c);
		Nx[fIndex] = v.x; Ny[fIndex] = v.y; Nz[fIndex] = v.z;
	
	}

	try  
	{    
		if ( !OpenMesh::IO::write_mesh(mesh, "output.obj") )   
	
		{       std::cerr << "Cannot write mesh to file 'output.off'" << std::endl;   } 
	}  

	catch( std::exception& x )  
	{    
		std::cerr << x.what() << std::endl;    

	}
}

vertex Mesh::faceNomal(vertex a,vertex b,vertex c)
{
	double x,y,z;
	x=(b.y-a.y)*(c.z-a.z)-(b.z-a.z)*(c.y-a.y);
	y=(b.z-a.z)*(c.x-a.x)-(b.x-a.x)*(c.z-a.z);
	z=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);

	double L;
	L=sqrt(x*x+y*y+z*z);
	vertex N;
	N.x=x/L;N.y=y/L;N.z=z/L;

	return N;
}


void Mesh::computeTemp(void)
{
	Edges.clear(); Points.clear(); Faces.clear();
	
	Edges.resize(mesh.n_edges());
	Points.resize(mesh.n_vertices());
	Faces.resize(mesh.n_faces());
	int nedges = 0;
	//存储点的信息
	mesh.update_normals();
	for (MyMesh::VertexIter vIt = mesh.vertices_begin(); vIt != mesh.vertices_end(); ++vIt)
	{
		const int vIndex = vIt.handle().idx();
		Points[vIndex].v_FaceIndex.clear();
		Points[vIndex].x = mesh.point(vIt)[0];
		Points[vIndex].y = mesh.point(vIt)[1];
		Points[vIndex].z = mesh.point(vIt)[2];
		for(MyMesh::VertexFaceIter vfIt = mesh.vf_begin(vIt); vfIt != mesh.vf_end(vIt); ++vfIt)
		{
			int vvIndex = vfIt.handle().idx();
			Points[vIndex].v_FaceIndex.push_back(vvIndex);
		}
	//	cout<<vIndex<<" "<<Points[vIndex].v_FaceIndex<<endl;
		for(MyMesh::VertexVertexIter vvIt = mesh.vv_begin(vIt); vvIt != mesh.vv_end(vIt); ++vvIt)
		{
			int vvIndex = vvIt.handle().idx();
			Points[vIndex].v_vertexIndex.push_back(vvIndex);
		}
	//	cout<<Points[vIndex].v_vertexIndex<<endl;
//		cout<<vIndex<<endl;
	}
	cout<<Points.size()<<endl;
	//存储面的信息
	for(MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		int fIndex = fIt.handle().idx();
		Faces[fIndex].fIndex.clear();
		MyMesh::FaceVertexIter fv_It = mesh.fv_iter(fIt.handle());
		MyMesh::VertexHandle v0 = fv_It; ++fv_It;
    	Faces[fIndex].a = v0.idx(); 
		MyMesh::VertexHandle v1 = fv_It; ++fv_It;
		Faces[fIndex].b = v1.idx();
		MyMesh::VertexHandle v2 = fv_It;
		Faces[fIndex].c = v2.idx(); 
	}
	//cout<<Faces.size()<<endl;
	//存储边的信息 
	double L = 0;
	for(MyMesh::EdgeIter eIt = mesh.edges_begin(); eIt != mesh.edges_end(); ++eIt)
	{
		int eIndex = eIt.handle().idx();
		MyMesh::VertexHandle v0 = mesh.to_vertex_handle(mesh.halfedge_handle(eIt,0));//每条边有两个半边。
		MyMesh::VertexHandle v1 = mesh.to_vertex_handle(mesh.halfedge_handle(eIt,1));
		int v0_Index = v0.idx();
		int v1_Index = v1.idx();
	    BOOL b1 = mesh.is_boundary(eIt); //是否为边界边是为1, 否为0
		if(b1 == 1) Edges[eIndex].flag = -1; else Edges[eIndex].flag = 1;
		MyMesh::FaceHandle f0 = mesh.face_handle(mesh.halfedge_handle(eIt,0));//每条边有两个面。
		MyMesh::FaceHandle f1 = mesh.face_handle(mesh.halfedge_handle(eIt,1));
		BOOL b2 = mesh.is_valid_handle(f0);//是否存在面，存在为1,不存在为0;
		BOOL b3 = mesh.is_valid_handle(f1);
       // cout<<eIndex<<"  "<<b1<<"  "<<b2<<" "<<b3<<endl;
		int f0_Index ,f1_Index;		
	    int f0_a,f0_b,f0_c,f1_a,f1_b,f1_c;
		if(b2 != 0)
		{ 
			f0_Index = f0.idx();Edges[eIndex].findex[0] = f0_Index;
			f0_a = Faces[f0.idx()].a ;  f0_b = Faces[f0.idx()].b;  f0_c = Faces[f0.idx()].c;
		}
		else { f0_Index = -1; Edges[eIndex].findex[0] = f0_Index; }
		if(b3 != 0)
		{
			f1_Index = f1.idx();Edges[eIndex].findex[1] = f1_Index;
			f1_a = Faces[f1.idx()].a ;  f1_b = Faces[f1.idx()].b;  f1_c = Faces[f1.idx()].c;
		}
		else {f1_Index = -1; Edges[eIndex].findex[1] = f1_Index;}
		Edges[eIndex].v1_index = v0_Index;
		Edges[eIndex].v2_index = v1_Index;		                                                                                    
		Edges[eIndex].eLength = 1.*sqrt((Points[v0_Index].x-Points[v1_Index].x)*(Points[v0_Index].x-Points[v1_Index].x)+
			                       (Points[v0_Index].y-Points[v1_Index].y)*(Points[v0_Index].y-Points[v1_Index].y)+
									(Points[v0_Index].z-Points[v1_Index].z)*(Points[v0_Index].z-Points[v1_Index].z));
		L += Edges[eIndex].eLength;
		if(f0_Index!=-1 &&f1_Index != -1)
		{
		if((Edges[eIndex].v1_index== f0_a &&Edges[eIndex].v2_index ==f0_b)||(Edges[eIndex].v1_index== f0_b &&Edges[eIndex].v2_index ==f0_c)||(Edges[eIndex].v1_index== f0_c &&Edges[eIndex].v2_index ==f0_a))
			Edges[eIndex].fflags[0] = 1;
		else 
			Edges[eIndex].fflags[0] = -1;
		Edges[eIndex].fflags[1] = -Edges[eIndex].fflags[0];
		}
		else
		{
			if(f0_Index = -1)
			{
			    if((Edges[eIndex].v1_index== f1_a &&Edges[eIndex].v2_index ==f1_b)||(Edges[eIndex].v1_index== f1_b &&Edges[eIndex].v2_index ==f1_c)||(Edges[eIndex].v1_index== f1_c &&Edges[eIndex].v2_index ==f1_a))
			      Edges[eIndex].fflags[1] = 1;
		       else 
			      Edges[eIndex].fflags[1] = -1;
                  Edges[eIndex].fflags[0] = 0;
			}
			if(f1_Index = -1)
			{
			    if((Edges[eIndex].v1_index== f0_a &&Edges[eIndex].v2_index ==f0_b)||(Edges[eIndex].v1_index== f0_b &&Edges[eIndex].v2_index ==f0_c)||(Edges[eIndex].v1_index== f0_c &&Edges[eIndex].v2_index ==f0_a))
			      Edges[eIndex].fflags[0] = 1;
		       else 
			      Edges[eIndex].fflags[0] = -1;
                  Edges[eIndex].fflags[1] = 0;
			}
		}

	}
	L = L/eNumber;// cout<<" L : "<<L<<endl;
	//存储面的信息
	for(MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		int fIndex = fIt.handle().idx();	
		Faces[fIndex].eIndex.clear();
		Faces[fIndex].flags.clear();
		for(MyMesh::FaceEdgeIter fe_It = mesh.fe_begin(fIt); fe_It != mesh.fe_end(fIt); ++fe_It)
		{
			int feIndex = fe_It.handle().idx();//边的标号
			Faces[fIndex].eIndex.push_back(feIndex);
			MyMesh::FaceHandle f0 = mesh.face_handle(mesh.halfedge_handle(fe_It,0));//每条边有两个面。
		    MyMesh::FaceHandle f1 = mesh.face_handle(mesh.halfedge_handle(fe_It,1));
			int fa = f0.idx(); int fb = f1.idx();
			if(Edges[feIndex].flag == -1) Faces[fIndex].fIndex.push_back(-1);
			else{
				if(fa != fIndex) Faces[fIndex].fIndex.push_back(fa);
				else Faces[fIndex].fIndex.push_back(fb);
			 }
			int v0 = Edges[feIndex].v1_index; 
			int v1 = Edges[feIndex].v2_index;
			if((v0 == Faces[fIndex].a &&v1 ==Faces[fIndex].b)||(v0 == Faces[fIndex].b &&v1 ==Faces[fIndex].c)||(v0 == Faces[fIndex].c &&v1 ==Faces[fIndex].a))
				Faces[fIndex].flags.push_back(1);
			else 
				Faces[fIndex].flags.push_back(-1);
		}
	

	}
//	faceneighbor();
	
}



void Mesh::UpdateVertex()
{
//定义变量及分配空间
	vector<double> newPoints_x,newPoints_y,newPoints_z; 
	newPoints_x.resize(mesh.n_vertices()); newPoints_y.resize(mesh.n_vertices()); newPoints_z.resize(mesh.n_vertices());
	vector<double> oldVertex_x,oldVertex_y,oldVertex_z; 
	oldVertex_x.resize(mesh.n_vertices()); oldVertex_y.resize(mesh.n_vertices()); oldVertex_z.resize(mesh.n_vertices());

    //存储点的一邻域的三角形（one_disk）
	for (MyMesh::VertexIter vIt = mesh.vertices_begin(); vIt != mesh.vertices_end(); ++vIt)
	{
		const int vIndex = vIt.handle().idx();		
		for(MyMesh::VertexFaceIter vfIt = mesh.vf_begin(vIt); vfIt != mesh.vf_end(vIt); ++vfIt)
		{
			int vvIndex = vfIt.handle().idx();
			Points[vIndex].v_FaceIndex.push_back(vvIndex);
		}	
	}
	//变量赋初值
	for (int i = 0; i < mesh.n_vertices(); i++)
	{
		newPoints_x[i] = Points[i].x;;
		newPoints_y[i] = Points[i].y;
		newPoints_z[i] = Points[i].z;
	
	}
	//迭代开始
	for(int k = 0; k< 40; k++)
	{
		//存储上一层点的坐标值;
	    for( int i = 0; i< mesh.n_vertices(); i++)
	    {
		    oldVertex_x[i] = newPoints_x[i];
		    oldVertex_y[i] = newPoints_y[i];
		    oldVertex_z[i] = newPoints_z[i];
	    }
		//遍历网格所有点
		for (int i = 0; i < mesh.n_vertices(); i++)
	    {	
			vertex v,point;  
			v.x = oldVertex_x[i]; v.y = oldVertex_y[i]; v.z = oldVertex_z[i];	 //点的坐标值  
			point.x = 0; point.y = 0; point.z = 0;
			//遍历点i的one_disk里的三角形
			for(int k = 0; k < Points[i].v_FaceIndex.size(); k++ ) 
		    {
				int vfIndex = Points[i].v_FaceIndex[k];//one_disk中三角形的标号
				int v1,v2,v3;  //三角形的三个点的标号
				vertex c, normal;  
				v1 = Faces[vfIndex].a; v2 = Faces[vfIndex].b; v3 = Faces[vfIndex].c;
				//三角形的法向
				normal.x = Fnormalx[vfIndex]; normal.y = Fnormaly[vfIndex]; normal.z = Fnormalz[vfIndex];	
				//三角形的重心坐标
		        c.x = (oldVertex_x[v1]+oldVertex_x[v2]+oldVertex_x[v3])/3;
			    c.y = (oldVertex_y[v1]+oldVertex_y[v2]+oldVertex_y[v3])/3;
			    c.z = (oldVertex_z[v1]+oldVertex_z[v2]+oldVertex_z[v3])/3;
			    double temp = normal.x*(c.x-v.x)+normal.y*(c.y-v.y)+normal.z*(c.z-v.z);
		        point.x += normal.x*temp;
			    point.y += normal.y*temp;
			    point.z += normal.z*temp;	   
		      }
			//计算新的点的位置
			   newPoints_x[i] += point.x/Points[i].v_FaceIndex.size();  
			   newPoints_y[i] += point.y/Points[i].v_FaceIndex.size(); 
			   newPoints_z[i] += point.z/Points[i].v_FaceIndex.size();	
	   }
	
  }
	for(MyMesh::VertexIter v_it = mesh.vertices_begin(); v_it!= mesh.vertices_end(); ++v_it)
	{
		int vIndex = v_it.handle().idx();
		mesh.point(v_it)[0] = newPoints_x[vIndex];
		mesh.point(v_it)[1] = newPoints_y[vIndex];
		mesh.point(v_it)[2] = newPoints_z[vIndex];
	}

	newPoints_x.clear(); newPoints_y.clear(); newPoints_z.clear();
	oldVertex_x.clear(); oldVertex_y.clear(); oldVertex_z.clear();
}



void Mesh::nProblemsolver1(double alpha, double r,
	                      std::vector<double>&lamda_x,
						  std::vector<double>&lamda_y,
						  std::vector<double>&lamda_z,
						  std::vector<double>&px,
						  std::vector<double>&py,
						  std::vector<double>&pz,
						  std::vector<MyMesh::Point>&InitFaceNormal,
						 Eigen::VectorXd &matF_X,
						 Eigen::VectorXd &matF_Y,
						 Eigen::VectorXd &matF_Z)
{
	int dimension = mesh.n_faces();
	int rows = dimension;
	int i,k;
	
	#pragma omp parallel 
	{
#pragma omp for
	for(k = 0; k < dimension; k++)
	{
		int fIndex = k; 
		
		matF_X[fIndex] = alpha*faceArea_[fIndex]*InitFaceNormal[fIndex][0];
		matF_Y[fIndex] = alpha*faceArea_[fIndex]*InitFaceNormal[fIndex][1];
		matF_Z[fIndex] = alpha*faceArea_[fIndex]*InitFaceNormal[fIndex][2];

		for(i = 0; i< 3; i++)
		{
			int feIndex = Faces[fIndex].eIndex[i];//面的三条边的标号
			int fflags = Faces[fIndex].flags[i];//边与面的方向标号
			double e_Length = Edges[feIndex].eLength;//边的长度
			 if(Edges[feIndex].flag != -1)
			 {
			matF_X[fIndex] += lamda_x[feIndex]*e_Length*fflags+r*px[feIndex]*fflags*e_Length;
			matF_Y[fIndex] += lamda_y[feIndex]*e_Length*fflags+r*py[feIndex]*fflags*e_Length;
			matF_Z[fIndex] += lamda_z[feIndex]*e_Length*fflags+r*pz[feIndex]*fflags*e_Length;
			 }
			 else
			 { 
				 matF_X[fIndex] += 0;
			     matF_Y[fIndex] += 0;
	             matF_Z[fIndex] += 0;
			 }

		}
		
	}
	}
}

void Mesh::matrix_A(double alpha,double r,SparseMatrix<double> &mat_X)
{
	int dimension = mesh.n_faces();
	int rows = dimension;
	int i,k;
	
	mat_X.reserve(VectorXi::Constant(rows,4));
	for(k = 0; k < dimension; k++)
	{
		int fIndex = k; 
		//填充三个分量矩阵
		mat_X.coeffRef(fIndex,fIndex) = alpha*faceArea_[fIndex];
		for(i = 0; i< 3; i++)
		{
			int ffIndex = Faces[fIndex].fIndex[i];//面的三个相邻面
			int feIndex = Faces[fIndex].eIndex[i];//面的三条边的标号
			int fflags = Faces[fIndex].flags[i];//边与面的方向标号
			double e_Length = Edges[feIndex].eLength;//边的长度
			 mat_X.coeffRef( fIndex ,fIndex )  += r*e_Length;
			if(Edges[feIndex].flag != -1)
			{
	     	   mat_X.coeffRef( fIndex ,ffIndex ) = r*e_Length*(-1);
			}
			else ;	
		}
	}
}
void Mesh::pProblem(double r,
	                    std::vector<double>&grad0,
						std::vector<double>&grad1,
						std::vector<double>&grad2,
						std::vector<double>&lambda_x,
						std::vector<double>&lambda_y,
						std::vector<double>&lambda_z,
						std::vector<double>&px,
						std::vector<double>&py,
						std::vector<double>&pz,
						std::vector<double>&nx,
						std::vector<double>&ny,
						std::vector<double>&nz,
						std::vector<MyMesh::Point>&InitFaceNormal)
{
	//omp_set_num_threads(NUM_THREADS);
			double w0,w1,w2;
			double theta, wij = 1.;
			double pi = 3.1415926;
//#pragma omp parallel 
		{
//#pragma omp for
		for ( int i = 0; i < eNumber; ++i)
		{ 	
			
				int a = Edges[i].findex[0];      int b = Edges[i].findex[1];
				int flags1 = Edges[i].fflags[0]; int flags2 = Edges[i].fflags[1];
				if(Edges[i].flag != -1)
				{  
					grad0[i] = nx[a]*flags1 + nx[b]*flags2; 
				    grad1[i] = ny[a]*flags1 + ny[b]*flags2; 
				    grad2[i] = nz[a]*flags1 + nz[b]*flags2;
				}
				else
				{
					grad0[i] = 0; 
					grad1[i] = 0; 
					grad2[i] = 0;
				}
		    //    theta = acos(InitFaceNormal[a][0]*InitFaceNormal[b][0]+ InitFaceNormal[a][1]*InitFaceNormal[b][1]
			//	           +InitFaceNormal[a][2]*InitFaceNormal[b][2]);
			//	theta = acos(nx[a]*nx[b] + ny[a]*ny[b] + nz[a]*nz[b]);
			//	theta = 1.*theta/(6.0*pi/18);
				theta = sqrt((nx[a]-nx[b])*(nx[a]-nx[b]) + (ny[a]-ny[b])*(ny[a]-ny[b]) + (nz[a]-nz[b])*(nz[a]-nz[b]));
				wij = 1.*exp(-1.0*pow(theta,4));

				w0 = grad0[i] - lambda_x[i]/r;  
				w1 = grad1[i] - lambda_y[i]/r;  
				w2 = grad2[i] - lambda_z[i]/r;  
				double ww = w0*w0 + w1*w1 + w2*w2;
				if(Edges[i].flag != -1)
				{  
//#pragma omp critical 
					if(ww <= std::pow((wij)/r,2.))
					{
						px[i] = 0;py[i] = 0;pz[i] = 0;
					}
					//#pragma omp critical
					if(ww> std::pow((wij)/r,2.))
					{
						double tempNorm = sqrt(ww);
						double t= (1. - wij/r/tempNorm);
						px[i] = t*w0;py[i] = t*w1;pz[i] = t*w2;
					}
				}
				else
				{
					px[i] = 0; py[i] = 0; pz[i] = 0;
				}
			}
	}
	
}


void Mesh::faceneighbor(void)
{
	vector<int>ffIndex;
	
	for(MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		ffIndex.clear();
		int fIndex = fIt.handle().idx();
	    int a,b,c; 
		a = Faces[fIndex].a ; b = Faces[fIndex].b; c = Faces[fIndex].c;
		int i1,i2,i3;
		i1 = Faces[fIndex].fIndex[0]; 
		i2 = Faces[fIndex].fIndex[1];
		i3 = Faces[fIndex].fIndex[2];

		for(int j = 0; j < Points[a].v_FaceIndex.size(); j++)
			ffIndex.push_back(Points[a].v_FaceIndex[j]);
		for(int k = 0; k < Points[b].v_FaceIndex.size(); k++)
			ffIndex.push_back(Points[b].v_FaceIndex[k]);
		for(int kk = 0; kk < Points[c].v_FaceIndex.size(); kk++)
			ffIndex.push_back(Points[c].v_FaceIndex[kk]);
	
		for(int i = 0; i < ffIndex.size(); i++)
		{
			if(ffIndex[i]==i1||ffIndex[i]==i2||ffIndex[i]==i3||ffIndex[i]==fIndex)
			{
				vector<int>::iterator  iter = ffIndex.begin() + i;
				ffIndex.erase(iter); i--;
			}
		}
		ffIndex.push_back(i1); ffIndex.push_back(i2); ffIndex.push_back(i3);
		Faces[fIndex].ffIndex = ffIndex;
		
	}

}


void Mesh::OurDenoisingMethod(double fidPara,double r,std::vector<MyMesh::Point>&InitFaceNormal)
{
	
	vector<double>grad0(eNumber) ;
    vector<double>grad1(eNumber) ;
    vector<double>grad2(eNumber) ;
    int dimension = fNumber;
	vector<double>nx(fNumber),ny(fNumber),nz(fNumber);
	vector<double>nxold(fNumber),nyold(fNumber),nzold(fNumber);
	vector<double> px(eNumber), py(eNumber), pz(eNumber);
	vector<double> lambda_x(eNumber), lambda_y(eNumber), lambda_z(eNumber);

	 Eigen::VectorXd matF_X(dimension);
	 Eigen::VectorXd matF_Y(dimension);
	 Eigen::VectorXd matF_Z(dimension);

	 Eigen::VectorXd x(dimension);
	 Eigen::VectorXd y(dimension);
	 Eigen::VectorXd z(dimension);

	/*   Parameters setting  */
    unsigned int innerL = 1; 
	int outL = -1;
	double stoppingCond, outTole =1e-5;	
	for (MyMesh::FaceIter fIt = mesh.faces_begin(); fIt != mesh.faces_end(); ++fIt)
	{
		int fIndex = fIt.handle().idx();
		nx[fIndex] = mesh.normal(fIt)[0];
		ny[fIndex] = mesh.normal(fIt)[1];
		nz[fIndex] = mesh.normal(fIt)[2];
		Fnormalx[fIndex] = mesh.normal(fIt)[0];//存储更新后的法向
		Fnormaly[fIndex] = mesh.normal(fIt)[1];;
		Fnormalz[fIndex] = mesh.normal(fIt)[2];;
	}
	for(int i = 0; i < eNumber; ++i)
	{
		px[i] = 0;
		lambda_x[i] = 0;
		py[i] = 0;
		lambda_y[i] = 0;
		pz[i] = 0;
		lambda_z[i] = 0;
	}
	double E1,E2;  E1 = 0; E2 = 0;
	double area = 1;//surfaceArea()/fNumber;
//	cout<<" begin:"<<endl;
	SparseMatrix<double >mat_X(dimension,dimension);
	matrix_A(fidPara,r,mat_X);//填充矩阵
	mat_X.makeCompressed();
	SimplicialLDLT<SparseMatrix<double>,Eigen::Upper>solver;
	solver.compute(mat_X); //矩阵分解
//	ConjugateGradient <SparseMatrix<double>>solver;
//	solver.compute(mat_X);		
	//程序开始
	int k = 0;
	do 
	// for(int iter = 0; iter < 500; iter++)
	{
   
		for (int i = 0; i < fNumber; i++)
		{
			int fIndex = i;
			nxold[fIndex] = nx[fIndex];
			nyold[fIndex] = ny[fIndex];
			nzold[fIndex] = nz[fIndex];
			
		}
		for (int iter = 0; iter < innerL; ++iter)
		{
		  //u_sub problem	
			clock_t u1,u2; u1 = clock();
			matF_X = matF_X*0;  matF_Y = matF_Y*0; matF_Z = matF_Z*0;
			nProblemsolver1(fidPara, r,lambda_x,lambda_y,lambda_z, px, py,pz,
										  InitFaceNormal,matF_X,matF_Y,matF_Z);
			x.setZero(); y.setZero(); z.setZero();
		//	omp_set_num_threads(NUM_THREADS);
#pragma omp parallel
			{
#pragma omp sections
			{
#pragma omp section
				x = solver.solve(matF_X);		
#pragma omp section
				y = solver.solve(matF_Y);
#pragma omp section
				z = solver.solve(matF_Z);
		     }
		   }
/*#pragma omp parallel
			{
#pragma omp sections
			{
#pragma omp section
			x = solver.solve(matF_X);
#pragma omp section
			y = solver.solve(matF_Y);
#pragma omp section
			z = solver.solve(matF_Z);
			}
			}*/
			for (int i = 0; i < fNumber; i++)
			{
				int fIndex = i;
				double temp = sqrt(x[fIndex]*x[fIndex]+y[fIndex]*y[fIndex]+z[fIndex]*z[fIndex]);
				Fnormalx[fIndex] = x[fIndex]/temp;
				Fnormaly[fIndex] = y[fIndex]/temp;
				Fnormalz[fIndex] = z[fIndex]/temp;

				nx[fIndex] = Fnormalx[fIndex];
				ny[fIndex] = Fnormaly[fIndex];
				nz[fIndex] = Fnormalz[fIndex];
			}
	
			pProblem(r,grad0,grad1,grad2,lambda_x,lambda_y,lambda_z,px,py,pz,nx,ny,nz,InitFaceNormal);
	
	}
		//*Update Lagrange multipliers (lambda_x,lambda_y,lambda_z).
			for (int eek = 0; eek < eNumber; eek++)
			{
				 
				lambda_x[eek] += r*(px[eek] - grad0[eek]);
				lambda_y[eek] += r*(py[eek] - grad1[eek]);
				lambda_z[eek] += r*(pz[eek] - grad2[eek]);

			}
			//  Compute the stopping condition     
			stoppingCond = 0.0;
		
			for(int i = 0; i < fNumber; ++i)
			{
				stoppingCond += (pow(nx[i] - nxold[i], 2.) + pow(ny[i] - nyold[i], 2.) + pow(nz[i] - nzold[i], 2.))*faceArea_[i]; 

			}
			cout<<" stoppingCond:"<<stoppingCond<<endl;
			k++;
			if(k>155) break;
	}while (stoppingCond > outTole); 

}




double Mesh::TriangleArea(double *p1,double *p2,double *p3)
{
	double S,d1,d2,d3,d;
	d1 = (p1[1]-p2[1])*(p3[2]-p2[2])-(p3[1]-p2[1])*(p1[2]-p2[2]);
	d2 = (p1[0]-p2[0])*(p3[1]-p2[1])-(p3[0]-p2[0])*(p1[1]-p2[1]);
	d3 = (p1[0]-p2[0])*(p3[2]-p2[2])-(p3[0]-p2[0])*(p1[2]-p2[2]);
	d = sqrt(d1*d1+d2*d2+d3*d3);
	S = 0.5*d;
	return S;
}


