#pragma once
#include<iostream>

#include<gmm/gmm.h>
#include<OpenMesh/Core/IO/MeshIO.hh>
#include<OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include"OpenMesh/Core/Mesh/Handles.hh"
//#include "mkl.h"
//#include "mkl_sparse_system/mkl_addon.h"
//#include "mkl_sparse_system/spmatrix.h"
#include <D:\Program Files (x86)\Eigen\Sparse>
#include <D:\Program Files (x86)\Eigen\IterativeLinearSolvers>
#include <D:\Program Files (x86)\Eigen\SparseCholesky>
#include <D:\Program Files (x86)\Eigen\Dense>
typedef OpenMesh::TriMesh_ArrayKernelT<> MyMesh;
typedef gmm::row_matrix<gmm::wsvector<double>> RowSparseMatrix;
typedef gmm::dense_matrix<double>DenseMatrix;
typedef Eigen::Triplet<double>T;
using namespace Eigen;
using namespace std;
struct vertex{
	double x;double y;double z;
	int degree;
	vector<int>v_FaceIndex;	
	vector<int>v_vertexIndex;
 };

struct face{
	int a;int b;int c;

	vector<int>eIndex;
	vector<int>flags;
	vector<int>fIndex;
	vector<int>ffIndex;
};
struct edge{
	int v1_index;
	int v2_index; 
	int findex[2];
	double eLength;
	int fflags[2];
	int vIndex[4];
	int flag;
	int f_flag;
   
};

class Mesh
{
public:
	Mesh(void);
	~Mesh(void);
	
	void readMeshFile(const string & filename);
	MyMesh mesh;
	void almMeshSmoothing(double fidPara,double lapPara,double r,double regParam,double nIndex);
	void computeMeshCoeff(void);
	std::vector<double> faceArea_;
	std::vector<double> newFaceArea;
	vector<double> Vx,Vy,Vz;
	vector<double> Nx,Ny,Nz;
	double maxx,minx,maxy,miny,maxz,minz;
    int eNumber,vNumber,fNumber;
	DenseMatrix featureDatas_;

	void addGaussianNoise(int eigIndex,double variance);
	double GaussianRandom(void);
	double triangleSurfaceArea(const vertex & pointA, const vertex &pointB, const vertex & pointC);

	void output(void);
	vertex faceNomal(vertex a,vertex b,vertex c);
    void computeTemp(void);
	vector<edge> Edges;
	vector<vertex> Points;
	vector<double> Fnormalx,Fnormaly,Fnormalz;
	vector<face> Faces;
	void UpdateVertex();	
	void nProblemsolver1(double alpha, double r,
	                      std::vector<double>&lamda_x,
						  std::vector<double>&lamda_y,
						  std::vector<double>&lamda_z,
						  std::vector<double>&px,
						  std::vector<double>&py,
						  std::vector<double>&pz,
						  std::vector<MyMesh::Point>&InitFaceNormal,
						 Eigen::VectorXd &matF_X,
						 Eigen::VectorXd &matF_Y,
						 Eigen::VectorXd &matF_Z);
	void matrix_A(double alpha, double r,SparseMatrix<double> &mat_X);
	void pProblem(double r,std::vector<double>&grad0,
						std::vector<double>&grad1,
						std::vector<double>&grad2,
						std::vector<double>&lambda_x,
						std::vector<double>&lambda_y,
						std::vector<double>&lambda_z,
						std::vector<double>&px,
						std::vector<double>&py,
						std::vector<double>&pz,
						std::vector<double>&nx,
						std::vector<double>&ny,
						std::vector<double>&nz,
						std::vector<MyMesh::Point>&InitFaceNormal);
	vector<double>nxx,nyy,nzz;
	vector<double>vxx,vyy,vzz;
	void faceneighbor();
	void OurDenoisingMethod(double fidPara,double r,std::vector<MyMesh::Point>&InitFaceNormal);
	int flags, meshflags;

	double TriangleArea(double *p1,double *p2,double *p3);
	
	int meshline;
};

