
// newMESHView.cpp : CnewMESHView ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "newMESH.h"
#endif
#include "MainFrm.h"
#include "newMESHDoc.h"
#include "newMESHView.h"
#include "DialogView.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CnewMESHView

IMPLEMENT_DYNCREATE(CnewMESHView, CView)

	BEGIN_MESSAGE_MAP(CnewMESHView, CView)
		// ��׼��ӡ����
		ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
		ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
		ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CnewMESHView::OnFilePrintPreview)
		ON_WM_CONTEXTMENU()
		ON_WM_RBUTTONUP()
		ON_WM_CREATE()
		ON_WM_DESTROY()
		ON_WM_SIZE()
		ON_WM_ERASEBKGND()
		ON_COMMAND(ID_FILE_OPEN, &CnewMESHView::OnFileOpen)
		ON_WM_MOUSEMOVE()
		ON_WM_LBUTTONDOWN()
		ON_WM_LBUTTONUP()
		ON_WM_RBUTTONDOWN()
//		ON_WM_MOUSEHWHEEL()
//		ON_WM_MOUSELEAVE()
ON_WM_MOUSEWHEEL()
ON_COMMAND(ID_NOISE, &CnewMESHView::OnNoise)
ON_COMMAND(ID_MESHSMOOTH, &CnewMESHView::OnMeshsmooth)
ON_COMMAND(ID_NONOISE, &CnewMESHView::OnNonoise)
ON_COMMAND(ID_MESH, &CnewMESHView::OnMesh)
	END_MESSAGE_MAP()

	// CnewMESHView ����/����

	CnewMESHView::CnewMESHView()
	{
		// TODO: �ڴ˴����ӹ������
		m_pDC=NULL;
		my_oldRect.right=my_oldRect.bottom=100;
		mytbar=FALSE;mysbar=FALSE;
		PanOffsetX=0;
        PanOffSetY=0;
        m_scale=1.0;
        m_mxTransform[0][0] = 1.0; m_mxTransform[0][1] = 0.0;
        m_mxTransform[0][2] = 0.0; m_mxTransform[0][3] = 0.0f;
        m_mxTransform[1][0] = 0.0; m_mxTransform[1][1] = 1.0;
        m_mxTransform[1][2] = 0.0; m_mxTransform[1][3] = 0.0f;
        m_mxTransform[2][0] = 0.0; m_mxTransform[2][1] = 0.0;
        m_mxTransform[2][2] = 1.0; m_mxTransform[2][3] = 0.0f;
        m_mxTransform[3][0] = 0.0f; m_mxTransform[3][1] = 0.0f;
        m_mxTransform[3][2] = 0.0f; m_mxTransform[3][3] = 1.0f;

		newNx.clear(); newNy.clear(); newNz.clear();
		newVx.clear(); newVy.clear(); newVz.clear();	
		resultVx.clear(); resultVy.clear(); resultVz.clear();
		resultNx.clear(); resultNy.clear(); resultNz.clear();
	
		resultFNormalx.clear(); resultFNormaly.clear(); resultFNormalz.clear();
		Vx.clear(); Vy.clear(); Vz.clear();
		Nx.clear(); Ny.clear(); Nz.clear();
		oldVx.clear(); oldVy.clear(); oldVz.clear();
		oldNx.clear(); oldNy.clear(); oldNz.clear();
		colormapR.clear(); colormapG.clear(); colormapB.clear();
		colormapR.resize(64); colormapG.resize(64); colormapB.resize(64);
		for(int i = 0; i < 8; i++)
		{
			colormapR[i] = 0; colormapG[i] = 0; colormapB[i] = 0.5+(i+1)*0.0625;
		}
		for(int i = 8; i< 24; i++)
		{
			colormapR[i] = 0; colormapG[i] = (i-7)*0.0625;  colormapB[i] = 1;
		}
		for(int i = 24; i< 40; i++)
		{
			colormapR[i] = (i-23)*0.0625; colormapG[i] = 1;  colormapB[i] = 1 - (i-23)*0.0625;
		}
		for(int i = 40; i< 56; i++)
		{
			colormapR[i] = 1; colormapG[i] = 1-(i-39)*0.0625;  colormapB[i] = 0;
		}
		for(int i = 56; i< 64; i++)
		{
			colormapR[i] = 1-(i-55)*0.0625; colormapG[i] = 0;  colormapB[i] = 0;
		}
		MenuButton=ID_MESH;
	
	}

	CnewMESHView::~CnewMESHView()
	{
		newNx.clear(); newNy.clear(); newNz.clear();
		newVx.clear(); newVy.clear(); newVz.clear();
	
		resultVx.clear(); resultVy.clear(); resultVz.clear();
		resultNx.clear(); resultNy.clear(); resultNz.clear();
	
		resultFNormalx.clear(); resultFNormaly.clear(); resultFNormalz.clear();
		Vx.clear(); Vy.clear(); Vz.clear();
		Nx.clear(); Ny.clear(); Nz.clear();
	
	
	}

	BOOL CnewMESHView::PreCreateWindow(CREATESTRUCT& cs)
	{
		// TODO: �ڴ˴�ͨ���޸�
		//  CREATESTRUCT cs ���޸Ĵ��������ʽ
		cs.style = WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
		return CView::PreCreateWindow(cs);
	}

	// CnewMESHView ����

	void CnewMESHView::OnDraw(CDC* /*pDC*/)
	{
		CnewMESHDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		if (!pDoc)
			return;
		DrawScene();
		
	}


	// CnewMESHView ��ӡ


	void CnewMESHView::OnFilePrintPreview()
	{
#ifndef SHARED_HANDLERS
		AFXPrintPreview(this);
#endif
	}

	BOOL CnewMESHView::OnPreparePrinting(CPrintInfo* pInfo)
	{
		// Ĭ��׼��
		return DoPreparePrinting(pInfo);
	}

	void CnewMESHView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
	{
		// TODO: ���Ӷ���Ĵ�ӡǰ���еĳ�ʼ������
	}

	void CnewMESHView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
	{
		// TODO: ���Ӵ�ӡ����е���������
	}

	void CnewMESHView::OnRButtonUp(UINT /* nFlags */, CPoint point)
	{
		ClientToScreen(&point);
		OnContextMenu(this, point);
		ReleaseCapture();
	}

	void CnewMESHView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
	{
#ifndef SHARED_HANDLERS
		theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
	}


	// CnewMESHView ���

#ifdef _DEBUG
	void CnewMESHView::AssertValid() const
	{
		CView::AssertValid();
	}

	void CnewMESHView::Dump(CDumpContext& dc) const
	{
		CView::Dump(dc);
	}

	CnewMESHDoc* CnewMESHView::GetDocument() const // �ǵ��԰汾��������
	{
		ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CnewMESHDoc)));
		return (CnewMESHDoc*)m_pDocument;
	}
#endif //_DEBUG


	// CnewMESHView ��Ϣ��������


	void CnewMESHView::InitOpengl(void)
	{
		PIXELFORMATDESCRIPTOR pfd;
		int n;
		HGLRC hrc;

		m_pDC=new CClientDC(this);

		ASSERT(m_pDC != NULL);

		if(!SetupPixelFormat())
			return;

		n=::GetPixelFormat(m_pDC->GetSafeHdc());

		::DescribePixelFormat(m_pDC->GetSafeHdc(), n,sizeof(pfd),&pfd);

		hrc=wglCreateContext(m_pDC->GetSafeHdc());
		wglMakeCurrent(m_pDC->GetSafeHdc(),hrc);

		GetClientRect(&my_oldRect);
        glClearDepth(1.0f);
        glEnable(GL_DEPTH_TEST);
	    glMatrixMode(GL_MODELVIEW);
	    glLoadIdentity();
	}


	BOOL CnewMESHView::SetupPixelFormat(void)
	{
		static PIXELFORMATDESCRIPTOR pfd = 
		{
			sizeof(PIXELFORMATDESCRIPTOR),
			1,
			PFD_DRAW_TO_WINDOW |
			PFD_SUPPORT_OPENGL|
			PFD_DOUBLEBUFFER, 
			PFD_TYPE_RGBA,
			24,
			0, 0, 0, 0, 0, 0,
			0,
			0,
			0,
			0, 0, 0, 0,
			32,
			0,
			0,
			PFD_MAIN_PLANE,
			0,
			0, 0, 0
		};
		int pixelformat;

		if((pixelformat = ChoosePixelFormat(m_pDC->GetSafeHdc(), &pfd)) == 0)
		{
			//MessageBox("ChoosePixelFormat failed");
			return FALSE;
		}

		if(SetPixelFormat(m_pDC->GetSafeHdc(), pixelformat, &pfd) == FALSE)
		{
			//MessageBox("SetPixelFormat failed");
			return FALSE;
		}

		return TRUE;
	}


	void CnewMESHView::DrawScene(void)
	{
	
	
		glClearColor(1.f,1.f,1.0f,1.0f);
		//�����ɫ����������Ȼ�����
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		mydraw();
			
		glShadeModel(GL_SMOOTH);	
	glEnable(GL_LIGHTING);
		glEnable(GL_LIGHT0);
	//	glEnable(GL_LIGHT1);
		glEnable(GL_COLOR_MATERIAL);
		glEnable(GL_DEPTH_TEST);
		
		glEnable(GL_NORMALIZE);
		glPushMatrix();
		glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
		
		if(Vx.size()&&Nx.size())
		{
			
			glBegin(GL_TRIANGLES);
			for(MyMesh::FaceIter f_it=Mmesh.mesh.faces_begin();f_it!=Mmesh.mesh.faces_end();++f_it)
			{
				int fIndex = f_it.handle().idx();
				glNormal3f(Nx[fIndex],Ny[fIndex],Nz[fIndex]);
			
				    glColor3f(0.21,0.5,0.9);
	
				   for(MyMesh::FaceVertexIter fv_it=Mmesh.mesh.fv_iter(*f_it);fv_it;++fv_it)
				   {
					   int vIndex=fv_it.handle().idx();
			
					   glVertex3f(Vx[vIndex],Vy[vIndex],Vz[vIndex]);
				   }
			
			}
			glEnd();

		}
	
	    glPopMatrix();
		glDisable(GL_LIGHTING);
		glFinish();
	//	Invalidate(true);
		SwapBuffers(wglGetCurrentDC());//����ʡ��
		
	}


   int CnewMESHView::OnCreate(LPCREATESTRUCT lpCreateStruct)
    {
		if (CView::OnCreate(lpCreateStruct) == -1)
			return -1;

		// TODO:  �ڴ�������ר�õĴ�������
		InitOpengl();

		material();
	//	Invalidate();
		return 0;
     }


	void CnewMESHView::OnDestroy()
	{
		CView::OnDestroy();

		// TODO: �ڴ˴�������Ϣ�����������

		HGLRC hrc;
		hrc = ::wglGetCurrentContext();
		::wglMakeCurrent(NULL,NULL);
		if(hrc)
			::wglDeleteContext(hrc);
		if(m_pDC)
			delete m_pDC;
	}


	void CnewMESHView::OnSize(UINT nType, int cx, int cy)
	{
		CView::OnSize(nType, cx, cy);

		if(cy > 0)
		{ 

			my_oldRect.right = cx;
			my_oldRect.bottom = cy;
            glViewport(0, 0, cx, cy);
         }
		RedrawWindow();
	}


	BOOL CnewMESHView::OnEraseBkgnd(CDC* pDC)
	{
		// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ

		return TRUE;
	}


	void CnewMESHView::OnFileOpen()
	{
		// TODO: �ڴ�����������������
		CString myFiles("OBJ Files (*.obj)|*.obj|PLY Files (*.ply)|*.ply|OFF Files (*.off)|*.off|All Files (*.*)|*.*||");
		CFileDialog fileDlg(OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,myFiles);
	    fileDlg.m_ofn.lpstrTitle=L"������Ի���";
	 //   fileDlg.m_ofn.lpstrFilter=L"Mesh File(*.obj) \0 *.obj";
		clock_t start,end;
		start=clock();
        CString fileName;     
		if(IDOK==fileDlg.DoModal())
		{   
			fileName=fileDlg.GetPathName();
			int len = fileName.GetLength();
			char*p = new char[len+1];
			for(int i = 0; i < len; ++i)
				p[i] = fileName[i];
			p[len]= '\0';
			
			Mmesh.readMeshFile(string(p));
	
			Mmesh.mesh.update_normals();
	//		Mmesh.mesh.update_face_normals();
       }
		vNumber = Mmesh.mesh.n_vertices();
		fNumber = Mmesh.mesh.n_faces();
		eNumber = Mmesh.mesh.n_edges();
	
		Vx.clear(); Vy.clear(); Vz.clear();
		Nx.clear(); Ny.clear(); Nz.clear();
	
		oldVx.clear(); oldVy.clear(); oldVz.clear();
		oldNx.clear(); oldNy.clear(); oldNz.clear();
	
	    Vx.resize(vNumber); Vy.resize(vNumber); Vz.resize(vNumber);
		Nx.resize(fNumber); Ny.resize(fNumber); Nz.resize(fNumber);
	
	    maxx=-1000;maxy=-1000;maxz=-1000;
	    minx=1000; miny=1000; minz=1000;
		int k=0;
		for(MyMesh::VertexIter v_it=Mmesh.mesh.vertices_begin();			
			v_it!=Mmesh.mesh.vertices_end();++v_it)
		{ 
			int vIndex = v_it.handle().idx();
			if(maxx<Mmesh.mesh.point(v_it).values_[0])maxx=Mmesh.mesh.point(v_it).values_[0];
			if(maxy<Mmesh.mesh.point(v_it).values_[1])maxy=Mmesh.mesh.point(v_it).values_[1];
			if(maxz<Mmesh.mesh.point(v_it).values_[2])maxz=Mmesh.mesh.point(v_it).values_[2];
			if(minx>Mmesh.mesh.point(v_it).values_[0])minx=Mmesh.mesh.point(v_it).values_[0];
			if(miny>Mmesh.mesh.point(v_it).values_[1])miny=Mmesh.mesh.point(v_it).values_[1];
			if(minz>Mmesh.mesh.point(v_it).values_[2])minz=Mmesh.mesh.point(v_it).values_[2];
		
		}
		double Length = sqrt((maxx-minx)*(maxx-minx)+(maxy-miny)*(maxy-miny)+(maxz-minz)*(maxz-minz));
		for(MyMesh::VertexIter v_it=Mmesh.mesh.vertices_begin();v_it!=Mmesh.mesh.vertices_end();++v_it)
		{ 
			int vIndex = v_it.handle().idx();
			Mmesh.mesh.point(v_it)[0] = Mmesh.mesh.point(v_it)[0]/Length;
			Mmesh.mesh.point(v_it)[1] = Mmesh.mesh.point(v_it)[1]/Length;
			Mmesh.mesh.point(v_it)[2] = Mmesh.mesh.point(v_it)[2]/Length;
			Vx[vIndex]=Mmesh.mesh.point(v_it)[0];
			Vy[vIndex]=Mmesh.mesh.point(v_it)[1];
			Vz[vIndex]=Mmesh.mesh.point(v_it)[2];
		}
		maxx = -1000;maxy = -1000;maxz = -1000;
	    minx = 1000; miny = 1000; minz = 1000;
	    for(MyMesh::VertexIter v_it=Mmesh.mesh.vertices_begin();			
			v_it!=Mmesh.mesh.vertices_end();++v_it)
		{ 
			int vIndex = v_it.handle().idx();
			if(maxx<Mmesh.mesh.point(v_it)[0])maxx=Mmesh.mesh.point(v_it)[0];
			if(maxy<Mmesh.mesh.point(v_it)[1])maxy=Mmesh.mesh.point(v_it)[1];
			if(maxz<Mmesh.mesh.point(v_it)[2])maxz=Mmesh.mesh.point(v_it)[2];
			if(minx>Mmesh.mesh.point(v_it)[0])minx=Mmesh.mesh.point(v_it)[0];
			if(miny>Mmesh.mesh.point(v_it)[1])miny=Mmesh.mesh.point(v_it)[1];
			if(minz>Mmesh.mesh.point(v_it)[2])minz=Mmesh.mesh.point(v_it)[2];
	
		}
		oldVx = Vx; oldVy = Vy; oldVz = Vz;
	    vertex v;
		Mmesh.vxx.resize(vNumber); Mmesh.vyy.resize(vNumber); Mmesh.vzz.resize(vNumber);
		Mmesh.vxx = Vx; Mmesh.vyy = Vy; Mmesh.vzz = Vz;
		faceNormalx.clear(); faceNormaly.clear(); faceNormalz.clear();
		faceNormalx.resize(Mmesh.mesh.n_faces());
		faceNormaly.resize(Mmesh.mesh.n_faces());
		faceNormalz.resize(Mmesh.mesh.n_faces());
		averageEdge = 0;
		for(MyMesh::FaceIter f_it=Mmesh.mesh.faces_begin();f_it!=Mmesh.mesh.faces_end();++f_it)
		{
			//	cout<<"normal:"<<Mmesh.mesh.normal(f_it)<<endl;
			int fIndex = f_it.handle().idx();
			MyMesh::FaceVertexIter fv_it=Mmesh.mesh.fv_iter(f_it.handle());
			vertex a,b,c;
		     fv_it;
			a.x=Mmesh.mesh.point(fv_it)[0];a.y=Mmesh.mesh.point(fv_it)[1];a.z=Mmesh.mesh.point(fv_it)[2];
		     (++fv_it);
			b.x=Mmesh.mesh.point(fv_it)[0];b.y=Mmesh.mesh.point(fv_it)[1];b.z=Mmesh.mesh.point(fv_it)[2];
		    (++fv_it);
			c.x=Mmesh.mesh.point(fv_it)[0];c.y=Mmesh.mesh.point(fv_it)[1];c.z=Mmesh.mesh.point(fv_it)[2];
			v=Mmesh.faceNomal(a,b,c);
			Nx[fIndex] = v.x; Ny[fIndex] = v.y; Nz[fIndex] = v.z;
		}
	
		oldNx = Nx;  oldNy = Ny;  oldNz = Nz;
		Mmesh.nxx.resize(fNumber); Mmesh.nyy.resize(fNumber); Mmesh.nzz.resize(fNumber);
		Mmesh.nxx = Nx; Mmesh.nyy = Ny; Mmesh.nzz = Nz;
		Mmesh.meshflags = 0; Mmesh.meshline = 0;
	for( MyMesh::EdgeIter eIt = Mmesh.mesh.edges_begin(); eIt != Mmesh.mesh.edges_end(); eIt++)
	{
		int eIndex = eIt.handle().idx();  
		MyMesh::VertexHandle v0 = Mmesh.mesh.to_vertex_handle(Mmesh.mesh.halfedge_handle(eIt,0));//ÿ������������ߡ�
		MyMesh::VertexHandle v1 = Mmesh.mesh.to_vertex_handle(Mmesh.mesh.halfedge_handle(eIt,1));
		int v0_Index = v0.idx();
		int v1_Index = v1.idx();
		averageEdge += sqrt((Vx[v0_Index]-Vx[v1_Index])*(Vx[v0_Index]-Vx[v1_Index])
			               +(Vy[v0_Index]-Vy[v1_Index])*(Vy[v0_Index]-Vy[v1_Index])
						   +(Vz[v0_Index]-Vz[v1_Index])*(Vz[v0_Index]-Vz[v1_Index]));
		
	 }
	averageEdge = averageEdge/Mmesh.mesh.n_edges();
     cout<<"averageEdge:"<<averageEdge<<endl;
	 try   {     if ( !OpenMesh::IO::write_mesh(Mmesh.mesh, "mesh.obj") )   
	{       std::cerr << "Cannot write mesh to file 'outputnoise.off'" << std::endl;   

	}   }  
	catch( std::exception& x )  
	{    
	std::cerr << x.what() << std::endl;    

	}
		Invalidate();
	}


	void CnewMESHView::OnMouseMove(UINT nFlags, CPoint point)
	{
		// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
		if (!nFlags)
		return;

	  if(nFlags==MK_RBUTTON)
	  {
         PanOffsetX+=(point.x-R_point.x)*len/my_oldRect.right;
		 PanOffSetY+=(point.y-R_point.y)*len/my_oldRect.bottom;
		 R_point=point;
		 Invalidate(FALSE);
//		 return;
		 
	  }
	  if(nFlags==MK_LBUTTON)//
	  {
		  if (m_eManipulationMode == Trackball)
		  {

		  
		  RotaTrans(point, m_vCurVec);
		  
		  GLfloat dx, dy, dz;
		  dx = m_vCurVec[0] - m_vPrevVec[0];
		  dy = m_vCurVec[1] - m_vPrevVec[1];
		  dz = m_vCurVec[2] - m_vPrevVec[2];
		  
		  m_fTrackingAngle = 200.0f * (float) sqrt(dx*dx + dy*dy + dz*dz);   //��ʼʱǰ���float��ֵΪ130.0f


		  m_vAxis[0] = m_vPrevVec[1]*m_vCurVec[2] - m_vPrevVec[2]*m_vCurVec[1];
		  m_vAxis[1] = m_vPrevVec[2]*m_vCurVec[0] - m_vPrevVec[0]*m_vCurVec[2];
		  m_vAxis[2] = m_vPrevVec[0]*m_vCurVec[1] - m_vPrevVec[1]*m_vCurVec[0];
		  
		  m_vPrevVec[0] = m_vCurVec[0];
		  m_vPrevVec[1] = m_vCurVec[1];
          m_vPrevVec[2] = m_vCurVec[2];
		  }
		  Invalidate(FALSE);
		  
//		  return;
	  }
		CView::OnMouseMove(nFlags, point);
	}


	void CnewMESHView::OnLButtonDown(UINT nFlags, CPoint point)
	{
		// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
		m_eManipulationMode = Trackball;
	 
	    RotaTrans(point,m_vPrevVec);
	    m_bIsTracking = true;
	    SetCapture();
		CView::OnLButtonDown(nFlags, point);
	}


	void CnewMESHView::OnLButtonUp(UINT nFlags, CPoint point)
	{
		// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
		m_eManipulationMode = None;
	    m_bIsTracking = false;
	    ReleaseCapture();
		CView::OnLButtonUp(nFlags, point);
	}


	void CnewMESHView::RotaTrans(CPoint point,GLdouble *pVec)
	{
		GLdouble  R=1.0;
		GLdouble  ViewportPointx=(2.0/my_oldRect.right)*(point.x-my_oldRect.right/2);   //ǰ�����(2/m_vViewport[2])��Ϊ�˽��������ȡֵ��Χӳ�䵽[-1,1]
		GLdouble  ViewportPointy=(2.0/my_oldRect.right )*(my_oldRect.bottom/2-point.y);//  (point.x-m_vViewport[2]/2)���ǰ�����任�õ���
		pVec[0]=ViewportPointx;
		pVec[1]=ViewportPointy;
		GLdouble  Distance=sqrt(ViewportPointx*ViewportPointx+ViewportPointy*ViewportPointy);
		if (Distance>R)
			pVec[2]=0;
		else
			pVec[2]=sqrt(R*R-ViewportPointx*ViewportPointx-ViewportPointy*ViewportPointy);

		GLdouble  a = sqrt(pVec[0]*pVec[0] + pVec[1]*pVec[1] + pVec[2]*pVec[2]);
		pVec[0] /= a;
		pVec[1] /= a;
		pVec[2] /= a;
	}


	void CnewMESHView::mydraw(void)
	{

	GLdouble middlex = 0.5*(maxx+minx);
	GLdouble middley = 0.5*(maxy+miny);
	GLdouble middlez = 0.5*(maxz+minz);
	GLdouble lenx   = maxx - minx;
	GLdouble leny	= maxy - miny;
	GLdouble lenz   = maxz - minz;

	len    = sqrt(lenx*lenx+leny*leny+lenz*lenz)*1.2;
	GLdouble width = len * my_oldRect.right / my_oldRect.bottom;
  
	float nearp=0.5*len*m_scale;
	float farp=5.0*len*m_scale;
	float left=-0.5*width-PanOffsetX;
	float right=0.5*width-PanOffsetX;
	float bottom=-0.5*len+PanOffSetY;
	float top=0.5*len+PanOffSetY;
//	cout << len << endl;


	glMatrixMode(GL_PROJECTION); 
	glLoadIdentity();
//	glFrustum(-0.5*width+left,0.5*width+right,-0.5*len+bottom,0.5*len+top,0.5*len,3.0*len);
    glFrustum(left,right,bottom,top,nearp,farp);


	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
//	glTranslatef(0.0f,0.0f,-7.0f);
	gluLookAt(0.0,0.0,2*nearp,0.0,0.0,-1.0,0.0,1.0,0.0);
	
	if (m_eManipulationMode == Trackball && m_bIsTracking == true)
	{
		glPushMatrix();
		glLoadIdentity();
		glRotatef(m_fTrackingAngle, m_vAxis[0], m_vAxis[1], m_vAxis[2]);   //����ģ�ͱ任
		glMultMatrixf((GLfloat *)m_mxTransform);
		glGetFloatv(GL_MODELVIEW_MATRIX, (GLfloat *)m_mxTransform);
		glPopMatrix();
	}
	glMultMatrixf((GLfloat *)m_mxTransform);
	
	
    glScalef(m_scale,m_scale,m_scale);
	
	glTranslatef(-middlex,-middley,-middlez);
	}


	void CnewMESHView::OnRButtonDown(UINT nFlags, CPoint point)
	{
		// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
		R_point=point;
	    SetCapture();
		CView::OnRButtonDown(nFlags, point);
	}


	BOOL CnewMESHView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
	{
		// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
		m_scale*=1.f+zDelta/1.0/my_oldRect.right;
	    Invalidate(FALSE);
		return CView::OnMouseWheel(nFlags, zDelta, pt);
	}


	void CnewMESHView::material(void)
	{

		GLfloat	lAmb[4];   GLfloat lDif[4]; GLfloat	lSpe[4]; GLfloat lPos[4];

	    GLfloat	llAmb[4];  GLfloat llDif[4];GLfloat	llSpe[4];GLfloat llPos[4];

	    GLfloat	mAmb[4];   GLfloat mDif[4]; GLfloat	mSpe[4]; GLfloat mEmi[4];
	    GLfloat		mShininess;
	
		llAmb[0]=0.0f;	llAmb[1]=0.0f;
	    llAmb[2]=0.0f;	llAmb[3]=1.0f;

	    llDif[0]=1.f;	llDif[1]=1.f;//��ɫ 
	    llDif[2]=1.f;	llDif[3]=1.0f;

	    llSpe[0]=1.f;	llSpe[1]=1.f;
	    llSpe[2]=1.0f;	llSpe[3]=1.0f;
	
	    llPos[0]=-2.0f;	llPos[1]=2.0f;
	    llPos[2]=2.0f;	llPos[3]=1.0f;

	    mAmb[0]=0.11f;	mAmb[1]=0.06f;
	    mAmb[2]=0.11f;	mAmb[3]=1.0f;
	
	    mDif[0]=0.43f;	mDif[1]=0.47;
	    mDif[2]=0.54f;	mDif[3]=1.f;
	
	    mSpe[0]=0.33f;	mSpe[1]=0.33f;
	    mSpe[2]=0.52f;	mSpe[3]=1.0f;
	
	    mEmi[0]=0.0f;	mEmi[1]=0.0f;
	    mEmi[2]=0.0f;	mEmi[3]=0.0f;
	
	    mShininess=10.8f;	
	
	   glLightfv(GL_LIGHT1,GL_AMBIENT,lAmb);//������
	   glLightfv(GL_LIGHT1,GL_DIFFUSE,lDif);//�������
	   glLightfv(GL_LIGHT1,GL_SPECULAR,lSpe);//���淴���
	   glLightfv(GL_LIGHT1,GL_POSITION,lPos);//���λ��
	
	   glLightfv(GL_LIGHT0,GL_AMBIENT,llAmb);
	   glLightfv(GL_LIGHT0,GL_DIFFUSE,llDif);
	   glLightfv(GL_LIGHT0,GL_SPECULAR,llSpe);
	   glLightfv(GL_LIGHT0,GL_POSITION,llPos);

	   glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,mAmb);
	   glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,mDif);
	   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,mSpe);
	   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,mEmi);
	   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,mShininess);
	}


	void CnewMESHView::OnNoise()
	{
		
	}


	void CnewMESHView::OnMeshsmooth()
	{
		// TODO: �ڴ�����������������
		MenuButton=ID_MESHSMOOTH;

		if(MenuButton==ID_MESHSMOOTH)
		{
	
		Mmesh.output();
		
		maxx=Mmesh.maxx;maxy=Mmesh.maxy;maxz=Mmesh.maxz;
		minx=Mmesh.minx;miny=Mmesh.miny;minz=Mmesh.minz;
		}
	}


	void CnewMESHView::OnNonoise()
	{
		// TODO: �ڴ�����������������
		
	}


	void CnewMESHView::OnMesh()
	{
		// TODO: �ڴ�����������������
		MenuButton=ID_MESH;
	}


	void CnewMESHView::almSmoothing(double alpha, double beta, double r, double temp,double nIndex)
	{
		//Mmesh.computeMeshCoeff();
		Mmesh.almMeshSmoothing(alpha,beta,r,temp,nIndex);
		Mmesh.output();
		newNx.clear(); newNy.clear(); newNz.clear();
		newVx.clear(); newVy.clear(); newVz.clear();
		resultVx.clear(); resultVy.clear(); resultVz.clear();
		resultNx.clear(); resultNy.clear(); resultNz.clear();
		resultFNormalx.clear(); resultFNormaly.clear(); resultFNormalz.clear();

		newNx = Mmesh.Nx; newNy = Mmesh.Ny; newNz = Mmesh.Nz;
        newVx = Mmesh.Vx; newVy = Mmesh.Vy; newVz = Mmesh.Vz;
	
		resultVx = Mmesh.Vx; resultVy = Mmesh.Vy; resultVz = Mmesh.Vz;
		resultNx = Mmesh.Nx; resultNy = Mmesh.Ny; resultNz = Mmesh.Nz;
		resultFNormalz = Mmesh.Fnormalz; resultFNormaly = Mmesh.Fnormaly; resultFNormalx = Mmesh.Fnormalx;

		maxx=Mmesh.maxx;maxy=Mmesh.maxy;maxz=Mmesh.maxz;
		minx=Mmesh.minx;miny=Mmesh.miny;minz=Mmesh.minz;
		
	}
