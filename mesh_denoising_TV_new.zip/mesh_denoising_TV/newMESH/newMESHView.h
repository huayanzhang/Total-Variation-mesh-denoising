
// newMESHView.h : CnewMESHView ��Ľӿ�
//

#pragma once
#include"glut.h"
#include"Mesh.h"
#include"newMESHDoc.h"
//#include<vector>
//using namespace std;

class CnewMESHView : public CView
{
protected: // �������л�����
	CnewMESHView();
	DECLARE_DYNCREATE(CnewMESHView)

// ����
public:
	CnewMESHDoc* GetDocument() const;
	CClientDC*m_pDC;
// ����
public:
	Mesh Mmesh;
	vector<double> Vx,Vy,Vz;
	vector<double> Nx,Ny,Nz;
	BOOL MenuButton;
	vector<double>noiseVx,noiseVy,noiseVz;
	vector<double>noiseNx,noiseNy,noiseNz;
	vector<double>colormapR,colormapG,colormapB;
// ��д
public:
	virtual void OnDraw(CDC* pDC);  // ��д�Ի��Ƹ���ͼ
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	
// ʵ��
public:
	virtual ~CnewMESHView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	void InitOpengl(void);
	BOOL SetupPixelFormat(void);
	void DrawScene(void);
	float PanOffSetY;
	float PanOffsetX;
	CRect my_oldRect;
	BOOL mytbar;
	BOOL mysbar;
	float m_scale;
	CPoint R_point;
	GLdouble m_vPrevVec[3], m_vCurVec[3];   //����Ļ��ӳ�䵽�������ϵĵ㣬����������ת��
	GLdouble len;
	bool    m_bIsTracking;
	GLdouble maxx,maxy,maxz;
	GLdouble minx,miny,minz;
	enum ManipulMode 
	{
		None=0, 
			Trackball, 
			Zooming, 
			Panning
	};
 ManipulMode m_eManipulationMode;
	
	GLfloat m_vAxis[3]; 
	GLfloat m_fTrackingAngle;
	 GLfloat m_mxTransform[4][4];
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnFileOpen();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	void RotaTrans(CPoint point,GLdouble *pVec);
	void mydraw(void);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
//	afx_msg void OnMouseHWheel(UINT nFlags, short zDelta, CPoint pt);
//	afx_msg void OnMouseLeave();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	void material(void);
	afx_msg void OnNoise();
	afx_msg void OnMeshsmooth();
	afx_msg void OnNonoise();
	afx_msg void OnMesh();
public:
	vector<double> oldVx,oldVy,oldVz;
	vector<double> oldNx,oldNy,oldNz;
	vector<double> newVx,newVy,newVz;
	vector<double> newNx,newNy,newNz;
	vector<double> resultVx,resultVy,resultVz;
	vector<double> resultNx,resultNy,resultNz;
	vector<double> faceNormalx,faceNormaly,faceNormalz;
	vector<double> resultFNormalx,resultFNormaly,resultFNormalz;
	vector<double> noisefNormalx,noisefNormaly,noisefNormalz;
	double averagex,averagey,averagez;
	void almSmoothing(double alpha, double beta, double r, double temp,double nIndex);
	//double *tv_Value;
	//int tv_ValueFlag;
	double averageEdge;
	double a,b,c,aa,bb,cc;
	int fNumber,eNumber,vNumber;
	double length;
};

#ifndef _DEBUG  // newMESHView.cpp �еĵ��԰汾
inline CnewMESHDoc* CnewMESHView::GetDocument() const
   { return reinterpret_cast<CnewMESHDoc*>(m_pDocument); }
#endif

